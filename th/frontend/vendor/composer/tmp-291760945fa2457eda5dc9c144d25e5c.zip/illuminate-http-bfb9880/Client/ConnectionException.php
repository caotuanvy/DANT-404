<?php

namespace Illuminate\Http\Client;

class ConnectionException extends HttpClientException
{
    //
}
